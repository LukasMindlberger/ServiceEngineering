var express = require('express');
var mysql = require("mysql");
var app = express();
var fs = require("fs");
var myParser = require("body-parser");
var cors = require('cors');

app.use(cors());
app.use(myParser.json());

//connection to dataBase
var con = mysql.createConnection({
	  host: "localhost",
	  user: "root",
	  password: "",
	  database: "users"
	});

con.connect(function(err){
	  if(err){
	    console.log('Error connecting to Db');
	    return;
	  }
	  console.log('Connection established');
});


//adding a new User
app.post('/addUser', function (req, res) {
	var mail = req.body.EMail;

	con.query('SELECT EMail FROM users WHERE EMail = "' + mail + '"' ,function(err, rows){
		//TODO Error-Handling
		if (rows.length !== 0){
			res.status(500).send("InternalServerError");
		} else {
			//TODO jeden neuen User automatisch der Group "public" hinzufügen
		  con.query('INSERT INTO users SET ?', req.body, function(err,result){
			  //TODO Error-Handling
				  console.log('Last insert ID:', req.body.EMail); 
				  res.status(200).send("OK"); 
			});
		} 
	});
});


//login
app.post('/login', function (req, res) {
	var user = req.body;
	var mail = req.body.EMail;
	var pw = req.body.Password;
	
	con.query('SELECT * FROM users WHERE EMail = "' + mail + '" AND Password = "' + pw + '"' ,function(err, rows){
		//TODO Error-Handling
		if (rows.length !== 0){
			//console.log("User gefunden!");
			user.Name = rows[0].Name;
			res.status(200).send(user);
		} else {
			//console.log("User nicht gefunden!");
			res.status(401).send("Unauthorized"); 
		}
	});
});

//create new Group
app.post('/addGroup', function (req, res) {

	var name = req.body.Name;
	var participantsName = req.body.Participants;
	var index;
	var participantsMail = [];
	
	con.query('SELECT MAX(GroupID) AS Maximum FROM users.group', function(err, rows){
			index = rows[0].Maximum + 1;	
	
//TODO fertig machen (Christian)!
	
	for (var i in participantsName){
			
			con.query('SELECT EMail FROM users WHERE Name = "' + participantsName[i].Name + '"', function(err, rows){
				participantsMail[i] = rows[0].EMail;
				
				if (i == participantsName.length - 1){
					console.log(index);
					console.log(participantsName);
					console.log(participantsMail);	
				}
		});

	}

	});
});

//list all Users
app.post('/listUsers', function(req, res){
	con.query('SELECT * FROM users' ,function(err, rows){
		var userList = [];
		for (var i in rows) {
			var user = {};
			user.Name = rows[i].Name;
			user.Password = rows[i].Password;
			user.EMail = rows[i].EMail;
			userList[i] = user;
		}
		res.status(200).send(userList);
	});	
});




//Hier kannst du dich austoben!!
app.post('listGroups', function(req, res){
//TODO	
});

app.post('createBlogEntity', function(req, res){
	//TODO	
});

app.post('getBlogEntities', function(req, res){
	//TODO	
});

app.post('addComment', function(req, res){
	//TODO	
});


var server = app.listen(8081, function () {

  var host = server.address().address;
  var port = server.address().port;
  console.log("Example app listening at http://%s:%s", host, port);

});